﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp1
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
            FrmSplash splash = new FrmSplash();
            splash.Show();
            Application.DoEvents();
            Thread.Sleep(3000);
            splash.Close();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pbxBuscaCEP_Click(object sender, EventArgs e)
        {
            FrmBuscarCep buscarCep = new FrmBuscarCep();
            buscarCep.Show();
        }

        private void pbxIR_Click(object sender, EventArgs e)
        {
            FrmIR iR = new FrmIR();
            iR.Show();
        }

        private void pbxIMC_Click(object sender, EventArgs e)
        {
            FrmIMC iMC = new FrmIMC();
            iMC.Show();
        }

        private void pbxConTemperatura_Click(object sender, EventArgs e)
        {
            FrmConversorTemperatura temperatura = new FrmConversorTemperatura();
            temperatura.Show();
        }

        private void pbxMediaConsumo_Click(object sender, EventArgs e)
        {
            FrmMediaConsumo mediaConsumo = new FrmMediaConsumo();
            mediaConsumo.Show();
        }
    }
}
