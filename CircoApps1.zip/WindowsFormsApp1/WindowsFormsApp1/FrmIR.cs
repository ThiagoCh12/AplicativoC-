﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FrmIR : Form
    {
        public FrmIR()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmIR_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txtValorSalario;
            txtValorSalario.Focus();
        }

        private void FrmIR_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Double salario,resultado;
            if (txtValorSalario.Text == "")
            {
                MessageBox.Show("Não há cálculos sem valores! Por Favor, preencha todos os campos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                salario = Convert.ToDouble(txtValorSalario.Text);
                resultado = Convert.ToDouble(0);
                lblResultadoAli.Text = resultado.ToString();
                
                txtValorSalario.Text = "";
                if(salario <= 2112)
                {
                    resultado = (salario * 0);
                    lblResultadoAli.Text = "Isento";
                    lblResultadoPar.Text = resultado.ToString("F");
                }
                else if (salario >= 2112.01 && salario <= 2826.65)
                {
                    resultado = (salario * 0.075);
                    lblResultadoAli.Text = "7.5%";
                    lblResultadoPar.Text = resultado.ToString("F");
                }
                else if (salario >= 2826.66  && salario <= 3751.05 )
                {
                    resultado = (salario * 0.15);
                    lblResultadoAli.Text = "15%";
                    lblResultadoPar.Text = resultado.ToString("F");
                }
                else if (salario >= 3751.06 && salario <= 4664.68)
                {
                    resultado = (salario * 0.225);
                    lblResultadoAli.Text = "22.5%";
                    lblResultadoPar.Text = resultado.ToString("F");
                }
                else if (salario > 4664.68 )
                {
                    resultado = (salario * 0.275);
                    lblResultadoAli.Text = "27.5%";
                    lblResultadoPar.Text = resultado.ToString("F");
                }

            }
        }
    }
}
